import Navi from './Navi';
const Header = () => {
    return (
        <div>Header
            <Navi />
        </div>
        
    )
}

export default Header;
